
//line x5.go:4
package main
func F5() {}
