package p

import "bad"
