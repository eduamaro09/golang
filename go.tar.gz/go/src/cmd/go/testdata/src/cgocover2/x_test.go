package p_test

import (
	. "cgocover2"
	"testing"
)

func TestF(t *testing.T) {
	F()
}
